import { StyleSheet, useWindowDimensions } from 'react-native';
import Svg, { Circle, Path } from 'react-native-svg';
import { colors } from '../theme';
import { sparkle } from './Logo';

// Generador pseudoaleatorio con semilla para que las estrellas no "salten" entre renders
function rng(seed: number) {
  return () => {
    seed = (seed * 16807) % 2147483647;
    return seed / 2147483647;
  };
}

export function Starfield({ seed = 7 }: { seed?: number }) {
  const { width, height } = useWindowDimensions();
  const r = rng(seed);
  const dots = Array.from({ length: 60 }, () => ({ x: r() * width, y: r() * height, s: r() * 1.6 + 0.4, o: r() * 0.6 + 0.2 }));
  const sparks = Array.from({ length: 5 }, () => ({ x: r() * width, y: r() * height, s: r() * 6 + 4 }));
  return (
    <Svg style={StyleSheet.absoluteFill} width={width} height={height} pointerEvents="none">
      {dots.map((d, i) => (
        <Circle key={i} cx={d.x} cy={d.y} r={d.s} fill={colors.cream} opacity={d.o} />
      ))}
      {sparks.map((s, i) => (
        <Path key={`s${i}`} d={sparkle(s.x, s.y, s.s)} fill={i % 2 ? colors.mint : colors.mustard} opacity={0.7} />
      ))}
    </Svg>
  );
}
