package expo.modules.hcecredencial

import android.content.Context

/**
 * Guarda el número de usuario en SharedPreferences para que el servicio HCE
 * pueda leerlo aunque la parte JavaScript de la app no esté corriendo.
 */
object CredencialStore {
    private const val PREFS = "RETROPOLIS_CREDENCIAL"
    private const val KEY_ID = "user_id"
    private const val KEY_LE = "little_endian"

    fun setUserId(context: Context, id: Long, littleEndian: Boolean) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putLong(KEY_ID, id)
            .putBoolean(KEY_LE, littleEndian)
            .apply()
    }

    fun clear(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().clear().apply()
    }

    /** null si no hay sesión iniciada. */
    fun getUserId(context: Context): Long? {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return if (prefs.contains(KEY_ID)) prefs.getLong(KEY_ID, 0L) else null
    }

    fun isLittleEndian(context: Context): Boolean =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_LE, true)
}
