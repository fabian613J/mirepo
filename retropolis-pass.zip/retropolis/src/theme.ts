/** Paleta "Era atómica": cielo nocturno, crema de diner, coral, mostaza y menta. */
export const colors = {
  night: '#14123A',
  nightDeep: '#0C0B26',
  panel: '#1F1C52',
  cream: '#F6EBD3',
  creamDim: '#C9BFA9',
  coral: '#FF5E3A',
  mustard: '#F5B82E',
  mint: '#3FC1B0',
  danger: '#FF7A7A',
};

export const fonts = {
  display: 'Righteous_400Regular',
  mono: 'SpaceMono_400Regular',
  monoBold: 'SpaceMono_700Bold',
};
