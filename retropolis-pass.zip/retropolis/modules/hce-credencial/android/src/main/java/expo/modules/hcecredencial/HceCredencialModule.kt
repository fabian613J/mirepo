package expo.modules.hcecredencial

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.nfc.NfcAdapter
import android.provider.Settings
import expo.modules.kotlin.exception.Exceptions
import expo.modules.kotlin.modules.Module
import expo.modules.kotlin.modules.ModuleDefinition
import java.lang.ref.WeakReference

/**
 * Puente entre JavaScript (React Native) y el servicio HCE nativo.
 *
 * JS -> nativo: setUserId / clearUserId / getStatus / openNfcSettings
 * nativo -> JS: eventos onScannerDetected / onScannerLost
 */
class HceCredencialModule : Module() {

    private val context: Context
        get() = appContext.reactContext ?: throw Exceptions.ReactContextLost()

    override fun definition() = ModuleDefinition {
        Name("HceCredencial")

        Events(EVENT_DETECTED, EVENT_LOST)

        OnCreate { instance = WeakReference(this@HceCredencialModule) }
        OnDestroy { instance = null }

        Function("getStatus") {
            val adapter = NfcAdapter.getDefaultAdapter(context)
            val hasHce = context.packageManager
                .hasSystemFeature(PackageManager.FEATURE_NFC_HOST_CARD_EMULATION)
            mapOf(
                "hasNfc" to (adapter != null),
                "hasHce" to hasHce,
                "nfcEnabled" to (adapter?.isEnabled == true),
                "userId" to CredencialStore.getUserId(context)?.toDouble()
            )
        }

        Function("setUserId") { id: Double, littleEndian: Boolean ->
            CredencialStore.setUserId(context, id.toLong(), littleEndian)
        }

        Function("clearUserId") {
            CredencialStore.clear(context)
        }

        Function("openNfcSettings") {
            val intent = Intent(Settings.ACTION_NFC_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
        }
    }

    companion object {
        private const val EVENT_DETECTED = "onScannerDetected"
        private const val EVENT_LOST = "onScannerLost"
        private var instance: WeakReference<HceCredencialModule>? = null

        fun emitScannerDetected(commandHex: String, responseHex: String, delivered: Boolean, userId: Long?) {
            instance?.get()?.sendEvent(
                EVENT_DETECTED,
                mapOf(
                    "command" to commandHex,
                    "response" to responseHex,
                    "delivered" to delivered,
                    "userId" to userId?.toDouble(),
                    "timestamp" to System.currentTimeMillis().toDouble()
                )
            )
        }

        fun emitScannerLost(reason: Int) {
            instance?.get()?.sendEvent(EVENT_LOST, mapOf("reason" to reason))
        }
    }
}
