import { Platform } from 'react-native';
import { requireOptionalNativeModule, type EventSubscription } from 'expo';

export type HceStatus = {
  hasNfc: boolean;
  hasHce: boolean;
  nfcEnabled: boolean;
  userId: number | null;
};

export type ScannerDetectedEvent = {
  /** APDU recibido del escáner, en hexadecimal (p. ej. "00 A4 04 00 05 F0 12 34 56 78 00") */
  command: string;
  /** APDU de respuesta enviado (4 bytes del ID + 90 00) */
  response: string;
  /** true si se entregó el número de usuario con 90 00 */
  delivered: boolean;
  userId: number | null;
  timestamp: number;
};

type NativeModuleShape = {
  getStatus(): HceStatus;
  setUserId(id: number, littleEndian: boolean): void;
  clearUserId(): void;
  openNfcSettings(): void;
  addListener(event: 'onScannerDetected', cb: (e: ScannerDetectedEvent) => void): EventSubscription;
  addListener(event: 'onScannerLost', cb: (e: { reason: number }) => void): EventSubscription;
};

// "Optional" para que la app no truene en Expo Go o en iOS (donde no hay HCE).
const Native = Platform.OS === 'android'
  ? requireOptionalNativeModule<NativeModuleShape>('HceCredencial')
  : null;

export const isAvailable = Native != null;

export function getStatus(): HceStatus {
  return Native?.getStatus() ?? { hasNfc: false, hasHce: false, nfcEnabled: false, userId: null };
}

/**
 * Guarda el número de usuario que se enviará al escáner.
 * littleEndian = true porque el firmware (ESP32) hace memcpy a un uint32_t.
 */
export function setUserId(id: number, littleEndian = true): void {
  Native?.setUserId(id, littleEndian);
}

export function clearUserId(): void {
  Native?.clearUserId();
}

export function openNfcSettings(): void {
  Native?.openNfcSettings();
}

export function addScannerListener(cb: (e: ScannerDetectedEvent) => void): EventSubscription | null {
  return Native?.addListener('onScannerDetected', cb) ?? null;
}

export function addScannerLostListener(cb: (e: { reason: number }) => void): EventSubscription | null {
  return Native?.addListener('onScannerLost', cb) ?? null;
}

/** Bytes (hex) que recibirá el escáner para un ID dado; útil para mostrar/depurar. */
export function idToHex(id: number, littleEndian = true): string {
  const bytes = [24, 16, 8, 0].map((s) => (id >>> s) & 0xff);
  if (littleEndian) bytes.reverse();
  return bytes.map((b) => b.toString(16).toUpperCase().padStart(2, '0')).join(' ');
}
