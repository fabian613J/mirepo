/**
 * ⚙️ Configuración única del proyecto. Ajusta aquí lo que cambie.
 */

/** URL base de la API monsterballgo (documentación de la práctica 2, sin "/" final). */
export const API_BASE_URL = 'https://monsterballgo.com/api';

/** POST x-www-form-urlencoded: user, pass (SHA-256), token. */
export const LOGIN_PATH = '/login';

/**
 * Endpoint de la tarea 10 (profilepic-expo) para cambiar la foto de perfil.
 * POST multipart/form-data con: token, id, image. Responde { pfp_url } o { error }.
 * Se usa https porque Android bloquea http en compilaciones de release.
 */
export const SET_PFP_URL = `${API_BASE_URL}/setpfp`;
export const API_TOKEN = 'code37';

/** Imagen por defecto si el usuario no tiene foto de perfil. */
export const DEFAULT_PFP = 'https://monsterballgo.com/media/usr/default.png';

/**
 * Orden de los 4 bytes enviados al escáner.
 * El firmware ScannerHTTP.ino corre en un ESP32 (little-endian) y hace
 * memcpy(&id, userId, 4), así que el byte menos significativo va primero.
 */
export const SEND_LITTLE_ENDIAN = true;

/** Datos para la pantalla de créditos. */
export const CREDITS = {
  team: 'Enanos',
  group: '900 CIB',
  date: '26 de octubre de 2026',
  members: [
    'Marcos Fabián Flores Arenas',
    'Saúl Waldemar Sosa Hernández',
  ],
};
