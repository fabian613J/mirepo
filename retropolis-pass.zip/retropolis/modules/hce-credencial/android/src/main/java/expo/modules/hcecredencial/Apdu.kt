package expo.modules.hcecredencial

/**
 * Utilidades del protocolo APDU (ISO/IEC 7816-4) usadas por la credencial.
 *
 * Command APDU:  CLA | INS | P1 | P2 | [Lc | DATA] | [Le]
 * Response APDU: [DATA] | SW1 | SW2
 */
object Apdu {
    /** AID propietario configurado en el firmware ScannerHTTP.ino y en retropolis_apdu_service.xml */
    val AID: ByteArray = hex("F012345678")

    // Status words (SW1 SW2)
    val SW_OK = byteArrayOf(0x90.toByte(), 0x00)                     // éxito
    val SW_CONDITIONS_NOT_SATISFIED = byteArrayOf(0x69, 0x85.toByte()) // no hay sesión iniciada
    val SW_FILE_NOT_FOUND = byteArrayOf(0x6A, 0x82.toByte())          // AID distinto al nuestro
    val SW_INS_NOT_SUPPORTED = byteArrayOf(0x6D, 0x00)                // instrucción desconocida
    val SW_UNKNOWN = byteArrayOf(0x6F, 0x00)                          // error sin diagnóstico preciso

    private const val CLA_ISO = 0x00
    private const val INS_SELECT = 0xA4
    private const val P1_SELECT_BY_NAME = 0x04

    /** ¿Es un SELECT por nombre (AID)? 00 A4 04 xx Lc AID... */
    fun isSelectAid(apdu: ByteArray): Boolean =
        apdu.size >= 5 &&
            (apdu[0].toInt() and 0xFF) == CLA_ISO &&
            (apdu[1].toInt() and 0xFF) == INS_SELECT &&
            (apdu[2].toInt() and 0xFF) == P1_SELECT_BY_NAME

    /** Extrae el AID (DATA) de un SELECT usando el campo Lc. */
    fun selectedAid(apdu: ByteArray): ByteArray? {
        val lc = apdu[4].toInt() and 0xFF
        if (apdu.size < 5 + lc) return null
        return apdu.copyOfRange(5, 5 + lc)
    }

    /**
     * Convierte el número de usuario a 4 bytes en orden LITTLE-ENDIAN.
     *
     * El firmware hace `memcpy(&id, userId, 4)` sobre un uint32_t en el ESP32,
     * que es little-endian: el primer byte recibido es el menos significativo.
     * Si enviáramos big-endian (como la app Kotlin de ejemplo), el usuario 3004
     * (0x00000BBC) llegaría al servidor como 0xBC0B0000 = 3154837504.
     */
    fun userIdToBytes(id: Long, littleEndian: Boolean): ByteArray {
        val v = id and 0xFFFFFFFFL
        val be = byteArrayOf(
            (v shr 24).toByte(),
            (v shr 16).toByte(),
            (v shr 8).toByte(),
            v.toByte()
        )
        return if (littleEndian) be.reversedArray() else be
    }

    fun hex(s: String): ByteArray =
        s.chunked(2).map { it.toInt(16).toByte() }.toByteArray()

    fun toHex(bytes: ByteArray?): String =
        bytes?.joinToString(" ") { "%02X".format(it) } ?: ""
}
