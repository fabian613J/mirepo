package expo.modules.hcecredencial

import android.content.Context
import android.nfc.cardemulation.HostApduService
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.util.Log

/**
 * Servicio de Host Card Emulation. Android lo invoca cuando un lector NFC
 * (el PN532 del escáner) envía un SELECT con nuestro AID F0 12 34 56 78.
 *
 * Respuesta: [4 bytes del número de usuario] + 90 00.
 * La app NO decide el acceso: el escáner manda el ID a su endpoint y enciende
 * el LED verde o rojo.
 */
class CredencialApduService : HostApduService() {

    override fun processCommandApdu(commandApdu: ByteArray?, extras: Bundle?): ByteArray {
        if (commandApdu == null) return Apdu.SW_UNKNOWN
        Log.d(TAG, "APDU IN: ${Apdu.toHex(commandApdu)}")

        val response: ByteArray = when {
            !Apdu.isSelectAid(commandApdu) -> Apdu.SW_INS_NOT_SUPPORTED
            !(Apdu.selectedAid(commandApdu)?.contentEquals(Apdu.AID) ?: false) -> Apdu.SW_FILE_NOT_FOUND
            else -> {
                val id = CredencialStore.getUserId(this)
                if (id == null) {
                    Apdu.SW_CONDITIONS_NOT_SATISFIED
                } else {
                    Apdu.userIdToBytes(id, CredencialStore.isLittleEndian(this)) + Apdu.SW_OK
                }
            }
        }

        Log.d(TAG, "APDU OUT: ${Apdu.toHex(response)}")

        val delivered = response.size == 6 // 4 bytes de ID + SW 90 00
        vibrate(delivered)
        HceCredencialModule.emitScannerDetected(
            commandHex = Apdu.toHex(commandApdu),
            responseHex = Apdu.toHex(response),
            delivered = delivered,
            userId = CredencialStore.getUserId(this)
        )
        return response
    }

    override fun onDeactivated(reason: Int) {
        // DEACTIVATION_LINK_LOSS (0): se alejó el teléfono; DEACTIVATION_DESELECTED (1): otro AID
        Log.d(TAG, "onDeactivated reason=$reason")
        HceCredencialModule.emitScannerLost(reason)
    }

    private fun vibrate(ok: Boolean) {
        val vibrator: Vibrator? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            (getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager)?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        }
        vibrator ?: return
        // Un pulso si se envió la credencial; dos pulsos cortos si no había sesión.
        val pattern = if (ok) longArrayOf(0, 120) else longArrayOf(0, 60, 80, 60)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator.vibrate(VibrationEffect.createWaveform(pattern, -1))
        } else {
            @Suppress("DEPRECATION")
            vibrator.vibrate(pattern, -1)
        }
    }

    companion object {
        private const val TAG = "RetropolisHCE"
    }
}
