import { ActivityIndicator, Pressable, StyleSheet, Text, View, type ViewStyle } from 'react-native';
import { colors, fonts } from '../theme';

type Props = {
  title: string;
  onPress: () => void;
  variant?: 'primary' | 'ghost';
  loading?: boolean;
  disabled?: boolean;
  style?: ViewStyle;
};

/** Botón con sombra sólida desplazada, al estilo de los letreros de diner. */
export function RetroButton({ title, onPress, variant = 'primary', loading, disabled, style }: Props) {
  const primary = variant === 'primary';
  return (
    <Pressable
      onPress={onPress}
      disabled={disabled || loading}
      accessibilityRole="button"
      style={({ pressed }) => [styles.outer, style, { opacity: disabled ? 0.5 : 1 }, pressed && styles.pressed]}
    >
      {primary && <View style={styles.shadow} />}
      <View style={[styles.face, primary ? styles.primary : styles.ghost]}>
        {loading ? (
          <ActivityIndicator color={colors.night} />
        ) : (
          <Text style={[styles.text, { color: primary ? colors.night : colors.cream }]}>{title}</Text>
        )}
      </View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  outer: { alignSelf: 'stretch' },
  pressed: { transform: [{ translateX: 3 }, { translateY: 3 }] },
  shadow: {
    position: 'absolute', left: 5, top: 5, right: -5, bottom: -5,
    borderRadius: 28, backgroundColor: colors.coral,
  },
  face: { minHeight: 54, borderRadius: 28, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 24 },
  primary: { backgroundColor: colors.mustard, borderWidth: 2, borderColor: colors.cream },
  ghost: { borderWidth: 2, borderColor: colors.creamDim },
  text: { fontFamily: fonts.display, fontSize: 18, letterSpacing: 1.5 },
});
