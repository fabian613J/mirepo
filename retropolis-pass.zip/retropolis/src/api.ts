import * as Crypto from 'expo-crypto';
import { File } from 'expo-file-system';
import { API_BASE_URL, API_TOKEN, DEFAULT_PFP, LOGIN_PATH, SET_PFP_URL } from './config';

/** Usuario en sesión, armado con la respuesta de POST /login. */
export type User = {
  id: number;
  /** Alias con el que inició sesión (la API devuelve el nombre en "username", por eso guardamos el que se escribió). */
  username: string;
  firstName: string;
  lastName: string;
  email: string;
  pfpUrl: string;
};

export class ApiError extends Error {
  constructor(message: string, public status?: number) {
    super(message);
  }
}

type Raw = Record<string, unknown>;

const str = (v: unknown) => (typeof v === 'string' ? v : v == null ? '' : String(v));

/** El servidor devuelve URLs http; Android bloquea http en release, así que las pasamos a https. */
const secure = (url: string) => url.replace(/^http:\/\//i, 'https://');

/** Traduce los errores documentados de la API a mensajes para el usuario. */
const ERRORS: Record<string, string> = {
  'Failed to login': 'Usuario o contraseña incorrectos.',
  'Data missing': 'Faltan datos: escribe usuario y contraseña.',
  Unauthorized: 'Token de la API no autorizado.',
  'Data must be sent in POST': 'Error interno: la petición debe ser POST.',
};

/**
 * POST /login (x-www-form-urlencoded) con user, pass (SHA-256) y token.
 * Respuesta: { username, id, xp, email, credits, firstname, lastname, pfp_url } o { error }.
 */
export async function login(username: string, password: string): Promise<User> {
  // La API exige la contraseña ya hasheada en SHA-256 (hex)
  const passHash = await Crypto.digestStringAsync(Crypto.CryptoDigestAlgorithm.SHA256, password);
  const form = Object.entries({ user: username, pass: passHash, token: API_TOKEN })
    .map(([k, v]) => `${k}=${encodeURIComponent(v)}`)
    .join('&');

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 10000);
  let res: Response;
  try {
    res = await fetch(`${API_BASE_URL}${LOGIN_PATH}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded', Accept: 'application/json' },
      body: form,
      signal: controller.signal,
    });
  } catch {
    throw new ApiError('No se pudo conectar con el servidor. Revisa tu conexión.');
  } finally {
    clearTimeout(timer);
  }

  let body: Raw = {};
  try {
    body = JSON.parse(await res.text());
  } catch {
    throw new ApiError(`Respuesta inesperada del servidor (${res.status}).`, res.status);
  }

  if (body.error) {
    const msg = str(body.error);
    throw new ApiError(ERRORS[msg] ?? msg, res.status);
  }
  const id = Number(body.id);
  if (!res.ok || !Number.isFinite(id)) {
    throw new ApiError(`Error del servidor (${res.status}).`, res.status);
  }
  return {
    id,
    username,
    firstName: str(body.firstname),
    lastName: str(body.lastname),
    email: str(body.email),
    pfpUrl: secure(str(body.pfp_url)) || DEFAULT_PFP,
  };
}

/**
 * Sube una nueva foto de perfil (mismo endpoint que la app de la tarea 10).
 * Devuelve la URL pública de la imagen guardada en el servidor.
 */
export async function setProfilePicture(id: number, localUri: string): Promise<string> {
  const form = new FormData();
  form.append('token', API_TOKEN);
  form.append('id', String(id));
  // File de expo-file-system se puede adjuntar directo a FormData (igual que en profilepic-expo)
  form.append('image', new File(localUri));

  let res: Response;
  try {
    // Igual que en la app de la tarea 10, que ya fue probada contra este endpoint
    res = await fetch(SET_PFP_URL, {
      method: 'POST',
      body: form,
      headers: { 'Content-Type': 'multipart/form-data' },
    });
  } catch {
    throw new ApiError('No se pudo conectar con el servidor.');
  }

  let body: { error?: string; pfp_url?: string } = {};
  try {
    body = await res.json();
  } catch {
    // respuesta no JSON
  }
  if (!res.ok || body.error) throw new ApiError(body.error ?? `Error HTTP ${res.status}`, res.status);
  if (!body.pfp_url) throw new ApiError('El servidor no devolvió la URL de la foto.');
  return secure(body.pfp_url);
}
