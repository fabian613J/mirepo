import { Redirect, useRouter } from 'expo-router';
import { useEffect, useRef, useState } from 'react';
import * as ImagePicker from 'expo-image-picker';
import { ActivityIndicator, Alert, Animated, AppState, Easing, Image, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import * as Hce from '../../modules/hce-credencial';
import { LogoMark } from '@/components/Logo';
import { RetroButton } from '@/components/RetroButton';
import { Starfield } from '@/components/Starfield';
import { setProfilePicture } from '@/api';
import { DEFAULT_PFP, SEND_LITTLE_ENDIAN } from '@/config';
import { useSession } from '@/session';
import { colors, fonts } from '@/theme';

type Scan = { at: Date; delivered: boolean; response: string };

export default function CredencialScreen() {
  const router = useRouter();
  const { user, signOut, updatePfp } = useSession();
  const [uploading, setUploading] = useState(false);
  const [status, setStatus] = useState<Hce.HceStatus>(() => Hce.getStatus());
  const [lastScan, setLastScan] = useState<Scan | null>(null);
  const [inField, setInField] = useState(false);
  const [pfpFailed, setPfpFailed] = useState(false);
  const pulse = useRef(new Animated.Value(0)).current;
  const flash = useRef(new Animated.Value(0)).current;

  // Revisar NFC al volver a la app (p. ej. después de activarlo en Ajustes)
  useEffect(() => {
    const sub = AppState.addEventListener('change', (s) => s === 'active' && setStatus(Hce.getStatus()));
    return () => sub.remove();
  }, []);

  // Animación de "radar" mientras espera al escáner
  useEffect(() => {
    const loop = Animated.loop(
      Animated.timing(pulse, { toValue: 1, duration: 1800, easing: Easing.out(Easing.quad), useNativeDriver: true }),
    );
    loop.start();
    return () => loop.stop();
  }, [pulse]);

  // Eventos emitidos por el servicio HCE nativo
  useEffect(() => {
    const a = Hce.addScannerListener((e) => {
      setInField(true);
      setLastScan({ at: new Date(e.timestamp), delivered: e.delivered, response: e.response });
      flash.setValue(1);
      Animated.timing(flash, { toValue: 0, duration: 1600, useNativeDriver: false }).start();
    });
    const b = Hce.addScannerLostListener(() => setInField(false));
    return () => {
      a?.remove();
      b?.remove();
    };
  }, [flash]);

  if (!user) return <Redirect href="/" />;

  const fullName = `${user.firstName} ${user.lastName}`.trim() || user.username;
  const ready = status.hasNfc && status.hasHce && status.nfcEnabled;
  const borderColor = flash.interpolate({ inputRange: [0, 1], outputRange: [colors.mustard, colors.mint] });
  const ringScale = pulse.interpolate({ inputRange: [0, 1], outputRange: [0.6, 1.6] });
  const ringOpacity = pulse.interpolate({ inputRange: [0, 1], outputRange: [0.8, 0] });

  // Cambiar foto de perfil con el endpoint de la tarea 10
  const pickAndUpload = async (source: 'camera' | 'library') => {
    const perm = source === 'camera'
      ? await ImagePicker.requestCameraPermissionsAsync()
      : await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!perm.granted) {
      Alert.alert('Permiso necesario', 'Autoriza el acceso para cambiar tu foto.');
      return;
    }
    const opts: ImagePicker.ImagePickerOptions = { mediaTypes: 'images', allowsEditing: true, aspect: [1, 1], quality: 0.7 };
    const result = source === 'camera'
      ? await ImagePicker.launchCameraAsync(opts)
      : await ImagePicker.launchImageLibraryAsync(opts);
    if (result.canceled) return;
    setUploading(true);
    try {
      const url = await setProfilePicture(user.id, result.assets[0].uri);
      setPfpFailed(false);
      await updatePfp(url);
    } catch (e) {
      Alert.alert('No se pudo subir la foto', e instanceof Error ? e.message : 'Intenta de nuevo.');
    } finally {
      setUploading(false);
    }
  };

  const changePhoto = () =>
    Alert.alert('Foto de perfil', '¿De dónde tomamos la nueva foto?', [
      { text: 'Cancelar', style: 'cancel' },
      { text: 'Galería', onPress: () => pickAndUpload('library') },
      { text: 'Cámara', onPress: () => pickAndUpload('camera') },
    ]);

  const logout = async () => {
    await signOut();
    router.replace('/');
  };

  return (
    <View style={styles.root}>
      <Starfield seed={23} />
      <SafeAreaView style={{ flex: 1 }}>
        <ScrollView contentContainerStyle={styles.scroll}>
          <View style={styles.header}>
            <LogoMark size={40} />
            <Text style={styles.headerText}>RETRÓPOLIS PASS</Text>
          </View>

          {/* Credencial tipo boleto */}
          <Animated.View style={[styles.ticket, { borderColor }]}>
            <View style={styles.ticketTop}>
              <Text style={styles.ticketKicker}>PASE DE ACCESO · TODAS LAS ATRACCIONES</Text>
            </View>
            <Pressable onPress={changePhoto} disabled={uploading} accessibilityRole="button" accessibilityHint="Cambiar foto de perfil">
              <View style={styles.photoRing}>
                <Image
                  source={{ uri: pfpFailed ? DEFAULT_PFP : user.pfpUrl }}
                  onError={() => setPfpFailed(true)}
                  style={styles.photo}
                  accessibilityLabel={`Foto de ${fullName}`}
                />
                {uploading && (
                  <View style={styles.photoOverlay}>
                    <ActivityIndicator color={colors.cream} size="large" />
                  </View>
                )}
              </View>
              <Text style={styles.changePhoto}>{uploading ? 'SUBIENDO…' : 'CAMBIAR FOTO'}</Text>
            </Pressable>
            <Text style={styles.name} numberOfLines={3} adjustsFontSizeToFit>{fullName}</Text>
            <Text style={styles.username}>@{user.username}</Text>

            <View style={styles.perforation}>
              {Array.from({ length: 18 }).map((_, i) => <View key={i} style={styles.hole} />)}
            </View>

            <Text style={styles.idLabel}>NÚMERO DE USUARIO</Text>
            <Text style={styles.idValue}>{String(user.id).padStart(4, '0')}</Text>
          </Animated.View>

          {/* Estado NFC */}
          {!Hce.isAvailable ? (
            <Banner tone="warn" title="Módulo NFC no disponible"
              body="Abre la app con el build de desarrollo de Android (no funciona en Expo Go)." />
          ) : !status.hasNfc || !status.hasHce ? (
            <Banner tone="warn" title="Este teléfono no puede emular tarjetas"
              body="Se necesita NFC con Host Card Emulation (HCE)." />
          ) : !status.nfcEnabled ? (
            <Banner tone="warn" title="NFC desactivado" body="Actívalo para usar tu pase."
              action="Abrir ajustes" onAction={Hce.openNfcSettings} />
          ) : (
            <View style={styles.nfcBox}>
              <View style={styles.radar}>
                <Animated.View style={[styles.radarRing, { transform: [{ scale: ringScale }], opacity: ringOpacity }]} />
                <View style={[styles.radarDot, { backgroundColor: inField ? colors.mint : colors.mustard }]} />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={styles.nfcTitle}>
                  {inField ? '¡Escáner detectado!' : 'Acerca tu teléfono al escáner'}
                </Text>
                <Text style={styles.nfcBody}>
                  {lastScan
                    ? `${lastScan.delivered ? 'Credencial enviada' : 'Sin credencial que enviar'} · ${lastScan.at.toLocaleTimeString()}\nRespuesta APDU: ${lastScan.response}`
                    : `Se enviarán 4 bytes: ${Hce.idToHex(user.id, SEND_LITTLE_ENDIAN)}`}
                </Text>
              </View>
            </View>
          )}

          <View style={styles.actions}>
            <RetroButton title="Créditos" onPress={() => router.push('/creditos')} />
            <RetroButton title="Cerrar sesión" variant="ghost" onPress={logout} style={{ marginTop: 14 }} />
          </View>
        </ScrollView>
      </SafeAreaView>
    </View>
  );
}

function Banner(p: { tone: 'warn'; title: string; body: string; action?: string; onAction?: () => void }) {
  return (
    <View style={styles.banner}>
      <Text style={styles.bannerTitle}>{p.title}</Text>
      <Text style={styles.bannerBody}>{p.body}</Text>
      {p.action && (
        <Pressable onPress={p.onAction} hitSlop={8}>
          <Text style={styles.bannerAction}>{p.action} →</Text>
        </Pressable>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.night },
  scroll: { padding: 20, paddingBottom: 36 },
  header: { flexDirection: 'row', alignItems: 'center', gap: 10, marginBottom: 16 },
  headerText: { fontFamily: fonts.display, color: colors.cream, fontSize: 20, letterSpacing: 2 },

  ticket: {
    backgroundColor: colors.cream, borderRadius: 28, borderWidth: 5, overflow: 'hidden',
    alignItems: 'center', paddingBottom: 22,
  },
  ticketTop: { alignSelf: 'stretch', backgroundColor: colors.coral, paddingVertical: 10, alignItems: 'center' },
  ticketKicker: { fontFamily: fonts.monoBold, color: colors.cream, fontSize: 10, letterSpacing: 1.5 },
  photoRing: {
    marginTop: 22, width: 168, height: 168, borderRadius: 84, borderWidth: 6, borderColor: colors.mustard,
    alignItems: 'center', justifyContent: 'center', backgroundColor: colors.night,
  },
  photo: { width: 150, height: 150, borderRadius: 75, backgroundColor: colors.panel },
  photoOverlay: {
    position: 'absolute', width: 150, height: 150, borderRadius: 75,
    backgroundColor: colors.night + 'AA', alignItems: 'center', justifyContent: 'center',
  },
  changePhoto: { fontFamily: fonts.monoBold, color: colors.coral, fontSize: 10, letterSpacing: 2, textAlign: 'center', marginTop: 8 },
  name: {
    fontFamily: fonts.display, color: colors.night, fontSize: 34, textAlign: 'center',
    marginTop: 16, paddingHorizontal: 18, lineHeight: 40,
  },
  username: { fontFamily: fonts.mono, color: colors.night + 'AA', fontSize: 14, marginTop: 2 },
  perforation: { flexDirection: 'row', justifyContent: 'space-between', alignSelf: 'stretch', paddingHorizontal: 14, marginVertical: 18 },
  hole: { width: 8, height: 8, borderRadius: 4, backgroundColor: colors.night + '30' },
  idLabel: { fontFamily: fonts.monoBold, color: colors.coral, fontSize: 12, letterSpacing: 3 },
  idValue: { fontFamily: fonts.display, color: colors.night, fontSize: 64, letterSpacing: 4, lineHeight: 72 },

  nfcBox: {
    flexDirection: 'row', alignItems: 'center', gap: 16, marginTop: 20, padding: 16,
    backgroundColor: colors.panel, borderRadius: 20, borderWidth: 1, borderColor: colors.mint + '55',
  },
  radar: { width: 52, height: 52, alignItems: 'center', justifyContent: 'center' },
  radarRing: { position: 'absolute', width: 52, height: 52, borderRadius: 26, borderWidth: 3, borderColor: colors.mint },
  radarDot: { width: 18, height: 18, borderRadius: 9 },
  nfcTitle: { fontFamily: fonts.display, color: colors.cream, fontSize: 17 },
  nfcBody: { fontFamily: fonts.mono, color: colors.creamDim, fontSize: 11, marginTop: 4, lineHeight: 16 },

  banner: { marginTop: 20, padding: 16, borderRadius: 20, backgroundColor: colors.coral + '22', borderWidth: 1, borderColor: colors.coral },
  bannerTitle: { fontFamily: fonts.display, color: colors.cream, fontSize: 17 },
  bannerBody: { fontFamily: fonts.mono, color: colors.creamDim, fontSize: 12, marginTop: 4 },
  bannerAction: { fontFamily: fonts.monoBold, color: colors.mustard, fontSize: 13, marginTop: 10 },

  actions: { marginTop: 24 },
});
