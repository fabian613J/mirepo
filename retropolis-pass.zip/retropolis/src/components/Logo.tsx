import { StyleSheet, Text, View } from 'react-native';
import Svg, { Circle, ClipPath, Defs, Ellipse, G, Path, Rect } from 'react-native-svg';
import { colors, fonts } from '../theme';

/** Estrella de 4 puntas estilo "googie" de los años 50. */
export const sparkle = (cx: number, cy: number, r: number) =>
  `M ${cx} ${cy - r} Q ${cx + r * 0.16} ${cy - r * 0.16} ${cx + r} ${cy} Q ${cx + r * 0.16} ${cy + r * 0.16} ${cx} ${cy + r} Q ${cx - r * 0.16} ${cy + r * 0.16} ${cx - r} ${cy} Q ${cx - r * 0.16} ${cy - r * 0.16} ${cx} ${cy - r} Z`;

/** Planeta con anillo: emblema del parque Retrópolis. */
export function LogoMark({ size = 120 }: { size?: number }) {
  return (
    <Svg width={size} height={size} viewBox="0 0 200 200">
      <Defs>
        <ClipPath id="front">
          {/* mitad inferior del anillo pasa por delante del planeta */}
          <Rect x="0" y="100" width="200" height="100" />
        </ClipPath>
        <ClipPath id="planet">
          <Circle cx="100" cy="100" r="52" />
        </ClipPath>
      </Defs>
      <G rotation={-18} origin="100, 100">
        <Ellipse cx="100" cy="100" rx="88" ry="24" fill="none" stroke={colors.mustard} strokeWidth="9" />
      </G>
      <Circle cx="100" cy="100" r="52" fill={colors.coral} />
      {/* franjas del planeta */}
      <G clipPath="url(#planet)">
        <Rect x="40" y="112" width="120" height="12" fill={colors.cream} opacity={0.9} />
        <Rect x="40" y="132" width="120" height="6" fill={colors.cream} opacity={0.9} />
        <Circle cx="82" cy="78" r="14" fill="#FF7F61" />
      </G>
      <G rotation={-18} origin="100, 100" clipPath="url(#front)">
        <Ellipse cx="100" cy="100" rx="88" ry="24" fill="none" stroke={colors.mustard} strokeWidth="9" />
      </G>
      <Path d={sparkle(164, 38, 20)} fill={colors.mint} />
      <Path d={sparkle(30, 160, 11)} fill={colors.cream} />
      <Circle cx="38" cy="52" r="4" fill={colors.cream} />
    </Svg>
  );
}

export function Logo({ size = 120, tagline = true }: { size?: number; tagline?: boolean }) {
  return (
    <View style={styles.wrap}>
      <LogoMark size={size} />
      <Text style={[styles.name, { fontSize: size * 0.3 }]}>RETRÓPOLIS</Text>
      {tagline && <Text style={styles.tag}>PARQUE TEMÁTICO · EST. 2026</Text>}
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { alignItems: 'center' },
  name: { fontFamily: fonts.display, color: colors.cream, letterSpacing: 2, marginTop: 4 },
  tag: { fontFamily: fonts.mono, color: colors.mustard, fontSize: 11, letterSpacing: 3, marginTop: 2 },
});
