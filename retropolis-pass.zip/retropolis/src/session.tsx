import * as SecureStore from 'expo-secure-store';
import { createContext, useCallback, useContext, useEffect, useState, type ReactNode } from 'react';
import * as Hce from '../modules/hce-credencial';
import { login as apiLogin, type User } from './api';
import { SEND_LITTLE_ENDIAN } from './config';

const KEY = 'retropolis.session';

type Session = {
  user: User | null;
  ready: boolean;
  signIn: (username: string, password: string) => Promise<void>;
  signOut: () => Promise<void>;
  updatePfp: (url: string) => Promise<void>;
};

const Ctx = createContext<Session | null>(null);

export function SessionProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [ready, setReady] = useState(false);

  // Restaurar sesión guardada al abrir la app
  useEffect(() => {
    SecureStore.getItemAsync(KEY)
      .then((raw) => {
        if (!raw) return;
        const saved = JSON.parse(raw) as User;
        setUser(saved);
        Hce.setUserId(saved.id, SEND_LITTLE_ENDIAN);
      })
      .catch(() => {})
      .finally(() => setReady(true));
  }, []);

  const signIn = useCallback(async (username: string, password: string) => {
    const u = await apiLogin(username.trim(), password);
    // El servicio HCE lee este valor cuando el escáner pregunta por la credencial
    Hce.setUserId(u.id, SEND_LITTLE_ENDIAN);
    await SecureStore.setItemAsync(KEY, JSON.stringify(u));
    setUser(u);
  }, []);

  const signOut = useCallback(async () => {
    Hce.clearUserId();
    await SecureStore.deleteItemAsync(KEY);
    setUser(null);
  }, []);

  // Después de subir una foto nueva, actualizar la credencial sin volver a iniciar sesión
  const updatePfp = useCallback(async (url: string) => {
    setUser((prev) => {
      if (!prev) return prev;
      // ?v= evita que la app muestre la foto anterior guardada en caché
      const next = { ...prev, pfpUrl: `${url}${url.includes('?') ? '&' : '?'}v=${Date.now()}` };
      SecureStore.setItemAsync(KEY, JSON.stringify(next)).catch(() => {});
      return next;
    });
  }, []);

  return <Ctx.Provider value={{ user, ready, signIn, signOut, updatePfp }}>{children}</Ctx.Provider>;
}

export function useSession() {
  const s = useContext(Ctx);
  if (!s) throw new Error('useSession debe usarse dentro de <SessionProvider>');
  return s;
}
