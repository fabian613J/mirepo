# Retrópolis Pass · Equipo Enanos

Credencial de acceso NFC para **Retrópolis**, parque temático de diversiones retrofuturista.
App en **React Native + Expo** que inicia sesión con la API de la práctica 2, muestra la credencial
del usuario y, mediante **Android HCE + APDU**, entrega su número de usuario (4 bytes) al escáner
Arduino Nano ESP32 + PN532 del repositorio [NFCAccesoFisico](https://github.com/fmg2099/NFCAccesoFisico).

## Estructura

```
src/
  app/
    _layout.tsx      Carga de fuentes, sesión y navegación (expo-router)
    index.tsx        Login (usuario + contraseña) y botón Créditos
    credencial.tsx   Credencial: foto, nombre completo, número de usuario, estado NFC y cambio de foto
    creditos.tsx     Integrantes, grupo, fecha y tech stack con logotipos
  config.ts          ⚙️ URL de la API, datos de créditos, orden de bytes
  api.ts             Login y subida de foto de perfil (endpoint de la tarea 10)
  session.tsx        Sesión persistente (SecureStore) + envío del ID al módulo HCE
  components/        Logo, botón y fondo de estrellas
modules/hce-credencial/      Módulo nativo propio (Expo Modules API, Kotlin)
  android/.../CredencialApduService.kt   HostApduService: responde al SELECT AID
  android/.../HceCredencialModule.kt     Puente JS ⇄ nativo + eventos
  android/.../Apdu.kt                    Constantes y utilidades APDU
  android/src/main/res/xml/retropolis_apdu_service.xml   AID F012345678
```

## Requisitos

- Expo SDK 57 / React Native 0.86 (mismas versiones que `profilepic-expo`).

- Node.js 20+ y Android Studio (SDK + JDK 17) **o** una cuenta de EAS.
- Teléfono Android con NFC y HCE (API 24+). **No funciona en Expo Go**: el módulo es nativo,
  se necesita un *development build*.
- Desinstala la app de ejemplo del profesor del mismo teléfono: usa el mismo AID y Android
  preguntaría cuál app responder.

## Instalación y ejecución

```bash
npm install
npx expo install --fix          # alinea versiones con el SDK de Expo
npx expo prebuild -p android --clean
npx expo run:android            # con el teléfono conectado por USB y depuración activada
```

APK sin Android Studio: `npx eas build -p android --profile preview` (requiere `eas.json`
con `"buildType": "apk"` en ese perfil).

## Configuración (src/config.ts)

| Constante | Uso |
|---|---|
| `API_BASE_URL`, `LOGIN_PATH` | `https://monsterballgo.com/api/login` (POST form-urlencoded: `user`, `pass` en SHA-256, `token`) |
| `SET_PFP_URL`, `API_TOKEN` | Endpoint `setpfp` de la tarea 10 (multipart: `token`, `id`, `image`) |
| `SEND_LITTLE_ENDIAN` | Orden de los 4 bytes del ID (ver abajo) |
| `CREDITS` | Integrantes, grupo y fecha de la pantalla de créditos |

El login sigue la *Documentación de la API "monsterballgo"*: la contraseña se hashea en SHA-256
(hex) con `expo-crypto` antes de enviarla, y de la respuesta se usan `id`, `firstname`, `lastname`,
`email` y `pfp_url`. El campo `username` de la respuesta en realidad trae el nombre, así que la app
muestra el alias que el usuario escribió. Los errores documentados (`Failed to login`,
`Data missing`, `Unauthorized`) se traducen a mensajes en español. Las URLs `http` de las fotos se
convierten a `https`, porque Android bloquea `http` en el APK de release.

## Cambiar la foto de perfil

En la credencial, toca la foto → **Cámara** o **Galería**. La imagen se recorta cuadrada y se envía
a `setpfp` con el número del usuario en sesión, igual que la app `profilepic-expo`. La URL que
devuelve el servidor reemplaza la foto de la credencial al instante.

## Protocolo con el escáner

1. El PN532 detecta el teléfono (ISO 14443-A) y envía `SELECT`:
   `00 A4 04 00 05 F0 12 34 56 78 00`
2. Android enruta el comando a `CredencialApduService` por el AID `F012345678`.
3. La app responde `[ID 4 bytes] 90 00`. Si no hay sesión responde `69 85`; AID distinto `6A 82`.
4. El escáner envía el ID a su endpoint y prende LED verde o rojo. **La app no decide el acceso.**
5. El teléfono vibra y la pantalla de credencial muestra "¡Escáner detectado!" con la respuesta APDU.

### ¿Por qué little-endian?

El firmware copia los 4 bytes con `memcpy(&id, userId, 4)` a un `uint32_t` del ESP32, que es
little-endian. La app de ejemplo en Kotlin envía big-endian; con ella el usuario 3004
(`00 00 0B BC`) llegaría como 3 154 837 504. Por eso aquí se envía `BC 0B 00 00`.
Si el profesor cambia el firmware a big-endian, pon `SEND_LITTLE_ENDIAN = false`.

## Créditos de logotipos

Trazos de [Simple Icons](https://simpleicons.org) (CC0). Las marcas pertenecen a sus dueños.
