import { useRouter } from 'expo-router';
import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import Svg, { Path } from 'react-native-svg';
import { Logo } from '@/components/Logo';
import { Starfield } from '@/components/Starfield';
import { CREDITS } from '@/config';
import { TECH_STACK } from '@/techLogos';
import { colors, fonts } from '@/theme';

export default function CreditosScreen() {
  const router = useRouter();
  return (
    <View style={styles.root}>
      <Starfield seed={41} />
      <SafeAreaView style={{ flex: 1 }}>
        <Pressable onPress={() => router.back()} style={styles.back} hitSlop={10} accessibilityRole="button">
          <Text style={styles.backText}>← Volver</Text>
        </Pressable>

        <ScrollView contentContainerStyle={styles.scroll}>
          <Logo size={90} tagline={false} />
          <Text style={styles.title}>Créditos</Text>

          <View style={styles.marquee}>
            <Text style={styles.kicker}>UNA PRODUCCIÓN DEL EQUIPO</Text>
            <Text style={styles.team}>{CREDITS.team}</Text>
            <View style={styles.divider} />
            {CREDITS.members.map((m) => (
              <Text key={m} style={styles.member}>{m}</Text>
            ))}
            <View style={styles.meta}>
              <Text style={styles.metaText}>Grupo {CREDITS.group}</Text>
              <Text style={styles.metaText}>{CREDITS.date}</Text>
            </View>
          </View>

          <Text style={styles.section}>TECH STACK</Text>
          <View style={styles.grid}>
            {TECH_STACK.map((t) => (
              <View key={t.name} style={styles.tech}>
                <View style={styles.logoTile}>
                  <Svg width={30} height={30} viewBox="0 0 24 24">
                    <Path d={t.path} fill={t.color} />
                  </Svg>
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={styles.techName} numberOfLines={2}>{t.name}</Text>
                  <Text style={styles.techRole} numberOfLines={2}>{t.role}</Text>
                </View>
              </View>
            ))}
          </View>
          <Text style={styles.legal}>
            Logotipos propiedad de sus respectivos dueños; se usan solo para identificar cada tecnología.
          </Text>
        </ScrollView>
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.night },
  back: { paddingHorizontal: 20, paddingTop: 8 },
  backText: { fontFamily: fonts.monoBold, color: colors.mustard, fontSize: 14 },
  scroll: { padding: 20, paddingBottom: 40 },
  title: { fontFamily: fonts.display, color: colors.cream, fontSize: 36, textAlign: 'center', marginTop: 8 },

  marquee: {
    marginTop: 18, backgroundColor: colors.panel, borderRadius: 24, padding: 20, alignItems: 'center',
    borderWidth: 3, borderColor: colors.mustard,
  },
  kicker: { fontFamily: fonts.monoBold, color: colors.mint, fontSize: 11, letterSpacing: 2 },
  team: { fontFamily: fonts.display, color: colors.coral, fontSize: 40, marginTop: 4 },
  divider: { height: 2, alignSelf: 'stretch', backgroundColor: colors.mustard + '55', marginVertical: 14 },
  member: { fontFamily: fonts.display, color: colors.cream, fontSize: 19, marginVertical: 3, textAlign: 'center' },
  meta: { flexDirection: 'row', justifyContent: 'space-between', alignSelf: 'stretch', marginTop: 16 },
  metaText: { fontFamily: fonts.mono, color: colors.creamDim, fontSize: 12 },

  section: { fontFamily: fonts.monoBold, color: colors.mustard, fontSize: 13, letterSpacing: 3, marginTop: 28, marginBottom: 12 },
  grid: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between' },
  tech: {
    width: '48.5%', flexDirection: 'row', alignItems: 'center', gap: 10, marginBottom: 10, padding: 10,
    borderRadius: 16, backgroundColor: colors.panel, borderWidth: 1, borderColor: colors.creamDim + '25',
  },
  logoTile: { width: 46, height: 46, borderRadius: 12, backgroundColor: colors.cream, alignItems: 'center', justifyContent: 'center' },
  techName: { fontFamily: fonts.display, color: colors.cream, fontSize: 14 },
  techRole: { fontFamily: fonts.mono, color: colors.creamDim, fontSize: 10, marginTop: 1 },
  legal: { fontFamily: fonts.mono, color: colors.creamDim + '99', fontSize: 10, textAlign: 'center', marginTop: 14 },
});
