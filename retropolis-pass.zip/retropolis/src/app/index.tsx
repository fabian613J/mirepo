import { Redirect, useRouter } from 'expo-router';
import { useRef, useState } from 'react';
import {
  KeyboardAvoidingView, Platform, Pressable, ScrollView, StyleSheet, Text, TextInput, View,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Logo } from '@/components/Logo';
import { RetroButton } from '@/components/RetroButton';
import { Starfield } from '@/components/Starfield';
import { useSession } from '@/session';
import { colors, fonts } from '@/theme';

export default function LoginScreen() {
  const router = useRouter();
  const { user, signIn } = useSession();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPass, setShowPass] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const passRef = useRef<TextInput>(null);

  if (user) return <Redirect href="/credencial" />;

  const submit = async () => {
    if (!username.trim() || !password) {
      setError('Escribe tu usuario y contraseña.');
      return;
    }
    setError(null);
    setLoading(true);
    try {
      await signIn(username, password);
      router.replace('/credencial');
    } catch (e) {
      setError(e instanceof Error ? e.message : 'No se pudo iniciar sesión.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={styles.root}>
      <Starfield seed={11} />
      <SafeAreaView style={{ flex: 1 }}>
        <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
          <ScrollView contentContainerStyle={styles.scroll} keyboardShouldPersistTaps="handled">
            <Logo size={130} />

            <View style={styles.card}>
              <Text style={styles.cardTitle}>Boletería espacial</Text>
              <Text style={styles.cardSub}>Inicia sesión para obtener tu pase de acceso</Text>

              <Text style={styles.label}>USUARIO</Text>
              <TextInput
                style={styles.input}
                value={username}
                onChangeText={setUsername}
                autoCapitalize="none"
                autoCorrect={false}
                autoComplete="username"
                placeholder="astronauta"
                placeholderTextColor={colors.creamDim + '80'}
                returnKeyType="next"
                onSubmitEditing={() => passRef.current?.focus()}
              />

              <Text style={styles.label}>CONTRASEÑA</Text>
              <View>
                <TextInput
                  ref={passRef}
                  style={[styles.input, { paddingRight: 84 }]}
                  value={password}
                  onChangeText={setPassword}
                  secureTextEntry={!showPass}
                  autoCapitalize="none"
                  autoComplete="password"
                  placeholder="••••••••"
                  placeholderTextColor={colors.creamDim + '80'}
                  returnKeyType="go"
                  onSubmitEditing={submit}
                />
                <Pressable style={styles.eye} onPress={() => setShowPass((v) => !v)} hitSlop={8}>
                  <Text style={styles.eyeText}>{showPass ? 'OCULTAR' : 'VER'}</Text>
                </Pressable>
              </View>

              {error && <Text style={styles.error}>{error}</Text>}

              <RetroButton title="DESPEGAR" onPress={submit} loading={loading} style={{ marginTop: 22 }} />
            </View>

            <RetroButton title="Créditos" variant="ghost" onPress={() => router.push('/creditos')} style={{ marginTop: 18 }} />
            <Text style={styles.foot}>¿Olvidaste tus datos? Solicítalos al profesor.</Text>
          </ScrollView>
        </KeyboardAvoidingView>
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.night },
  scroll: { flexGrow: 1, justifyContent: 'center', padding: 24, paddingBottom: 32 },
  card: {
    marginTop: 28, backgroundColor: colors.panel, borderRadius: 24, padding: 22,
    borderWidth: 2, borderColor: colors.mint + '55',
  },
  cardTitle: { fontFamily: fonts.display, fontSize: 24, color: colors.cream },
  cardSub: { fontFamily: fonts.mono, fontSize: 12, color: colors.creamDim, marginTop: 4, marginBottom: 8 },
  label: { fontFamily: fonts.monoBold, fontSize: 11, color: colors.mint, letterSpacing: 2, marginTop: 14, marginBottom: 6 },
  input: {
    backgroundColor: colors.nightDeep, color: colors.cream, fontFamily: fonts.mono, fontSize: 16,
    borderRadius: 14, paddingHorizontal: 16, paddingVertical: 13, borderWidth: 1, borderColor: colors.creamDim + '40',
  },
  eye: { position: 'absolute', right: 14, top: 0, bottom: 0, justifyContent: 'center' },
  eyeText: { fontFamily: fonts.monoBold, fontSize: 11, color: colors.mustard, letterSpacing: 1 },
  error: { fontFamily: fonts.mono, color: colors.danger, fontSize: 13, marginTop: 14 },
  foot: { fontFamily: fonts.mono, color: colors.creamDim, fontSize: 11, textAlign: 'center', marginTop: 14 },
});
